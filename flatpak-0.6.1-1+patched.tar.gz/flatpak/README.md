# Flatpak

flatpak is a system for building, distributing and running sandboxed
desktop applications on Linux.

See https://flatpak.org/ for more information.
